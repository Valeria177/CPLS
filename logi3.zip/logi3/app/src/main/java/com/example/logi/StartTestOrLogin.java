package com.example.logi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class StartTestOrLogin extends AppCompatActivity {
    private String token;
    private Button startTheTest;
    private Button login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_test_or_login);
        Intent intent = getIntent();
        token = intent.getStringExtra("token_key");

//        if (token != null) {
//            startTheTest.setVisibility(View.VISIBLE);
//
//        } else {
//            login.setVisibility(View.INVISIBLE);
//
//        }
    }


        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.startTheTest:
                    Intent intent = new Intent(StartTestOrLogin.this, LoginClient.class);
                    startActivity(intent);
                    goToTestActivity("yes");
                    break;

                case R.id.login:

                    Intent intent2 = new Intent(StartTestOrLogin.this, LoginClient.class);
                    startActivity(intent2);
                    break;

                // the rest of the buttons go here
                default:
                    Log.e("YourTAG", "Default in onClick hit!");
                    break;
            }
        }

    public void goToTestActivity(String isAuth) {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        String URL = "https://backandroid.herokuapp.com/api/test/startTest";
        StringRequest request = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                    }

                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("error is ", "" + error);
            }
        }) {
            @Override
            public Map getHeaders() throws AuthFailureError {
                Map params = new HashMap();
                params.put("Authorization", "Bearer "+ token);
                return params;
            }
        };
        requestQueue.add(request);

        Intent test = new Intent(this, TestActivity.class);
        test.putExtra("token_key", token);
        test.putExtra("isAuth", isAuth);
        startActivity(test);
    }

}