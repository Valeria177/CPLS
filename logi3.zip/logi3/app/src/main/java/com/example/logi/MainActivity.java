package com.example.logi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button onActivityMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        onActivityMain = findViewById(R.id.onStartTheTest);
        onActivityMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                Context context = MainActivity.this;
                Class destinationActivity = StartTestOrLogin.class;
                Intent mainActivityIntent = new Intent(context, destinationActivity);
                startActivity(mainActivityIntent);

            }
        });
    }
}
