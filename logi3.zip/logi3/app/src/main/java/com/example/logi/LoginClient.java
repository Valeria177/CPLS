package com.example.logi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginClient extends AppCompatActivity {
    //private Button onRegister;

    public EditText editTextName;
    public EditText editTextTextPassword;
    public Button btnAuthSubmit;
    public String token = "null";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        btnAuthSubmit = (Button) findViewById(R.id.btnAuthSubmit);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

    }

    public void onClick(View v) throws InterruptedException {
        switch (v.getId()) {
            case R.id.btnAuthSubmit:
                Intent intent = new Intent(LoginClient.this, Test.class);
                startActivity(intent);
                btnAuth(v);
                break;

            case R.id.register:

                Intent intent2 = new Intent(LoginClient.this, Register.class);
                startActivity(intent2);
                break;

            // the rest of the buttons go here
            default: Log.e("YourTAG", "Default in onClick hit!");
                break;
        }
    }

    public void btnAuth(View view) throws InterruptedException {
        editTextName = (EditText) findViewById(R.id.editTextName);
        editTextTextPassword = (EditText) findViewById(R.id.editTextTextPassword);
        String username = editTextName.getText().toString();
        String password = editTextTextPassword.getText().toString();
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        String URL = "https://backandroid.herokuapp.com/api/reg/signin";
        HashMap<String, String> params = new HashMap<>();
        params.put("password", password);
        params.put("username", username);

        JsonObjectRequest request_json = new JsonObjectRequest(URL, new JSONObject(params),
                response -> {
                    try {
                        token = response.getString("accessToken");
                        Log.d("Ключ", token);
                        startActivity(token);
                        Toast toast = Toast.makeText(getApplicationContext(),
                                "Успешно", Toast.LENGTH_SHORT);
                        toast.show();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }, error -> {
                    Toast toast = Toast.makeText(getApplicationContext(),
                            "Ошибка. Но вы можете пройти тест в качестве неавторизованного пользователя", Toast.LENGTH_SHORT);
                    toast.show();
                }) {
            @Override
            public String getBodyContentType() {
                return "application/json; charset=utf-8";
            }
        };
        requestQueue.add(request_json);
    }
//    public void startActivity(String string) {
//        Intent main = new Intent(this, TestActivity.class);
//        main.putExtra("token_key", string);
//        startActivity(main);
//        finish();
//    }
    public void startActivity(String isAuth) {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        String URL = "https://backandroid.herokuapp.com/api/test/startTest";
        StringRequest request = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                    }

                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("error is ", "" + error);
            }
        }) {
            @Override
            public Map getHeaders() throws AuthFailureError {
                Map params = new HashMap();
                params.put("Authorization", "Bearer "+ token);
                return params;
            }
        };
        requestQueue.add(request);

        Intent test = new Intent(this, TestActivity.class);
        test.putExtra("token_key", token);
        test.putExtra("isAuth", isAuth);
        startActivity(test);
    }

}
